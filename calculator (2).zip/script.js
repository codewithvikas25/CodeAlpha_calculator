// Simple calculator logic
const display = document.getElementById('display');
let current = '0';
let previous = null;
let operator = null;
let resetNext = false;

function updateDisplay() {
  display.textContent = current;
}

function inputNumber(num) {
  if (resetNext) {
    current = '0';
    resetNext = false;
  }
  if (num === '.' && current.includes('.')) return;
  if (current === '0' && num !== '.') current = num;
  else current = current + num;
}

function clearAll() {
  current = '0';
  previous = null;
  operator = null;
  resetNext = false;
}

function applyOperator(op) {
  if (operator && previous !== null && !resetNext) {
    compute();
  }
  operator = op;
  previous = parseFloat(current);
  resetNext = true;
}

function compute() {
  if (operator === null || previous === null) return;
  const a = previous;
  const b = parseFloat(current);
  let result = 0;
  switch(operator) {
    case '+': result = a + b; break;
    case '-': result = a - b; break;
    case '*': result = a * b; break;
    case '/': result = b === 0 ? 'Error' : a / b; break;
    default: return;
  }
  current = String(result).slice(0, 12);
  operator = null;
  previous = null;
  resetNext = true;
}

function toggleNeg() {
  if (current === '0') return;
  current = current.startsWith('-') ? current.slice(1) : '-' + current;
}

function percent() {
  current = String(parseFloat(current) / 100);
}

document.querySelectorAll('.btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const num = btn.dataset.num;
    const action = btn.dataset.action;
    if (num !== undefined) {
      inputNumber(num);
      updateDisplay();
      return;
    }
    if (action) {
      if (action === 'clear') {
        clearAll();
        updateDisplay();
        return;
      }
      if (action === 'neg') {
        toggleNeg();
        updateDisplay();
        return;
      }
      if (action === 'percent') {
        percent();
        updateDisplay();
        return;
      }
      if (action === '=') {
        compute();
        updateDisplay();
        return;
      }
      // operator actions: + - * /
      applyOperator(action);
      updateDisplay();
    }
  });
});

// keyboard support
window.addEventListener('keydown', (e) => {
  if ((e.key >= '0' && e.key <= '9') || e.key === '.') {
    inputNumber(e.key);
    updateDisplay();
    return;
  }
  if (['+','-','*','/'].includes(e.key)) {
    applyOperator(e.key);
    updateDisplay();
    return;
  }
  if (e.key === 'Enter' || e.key === '=') {
    compute();
    updateDisplay();
    return;
  }
  if (e.key === 'Backspace') {
    current = current.length > 1 ? current.slice(0, -1) : '0';
    updateDisplay();
    return;
  }
  if (e.key.toLowerCase() === 'c') {
    clearAll();
    updateDisplay();
  }
});

updateDisplay();
