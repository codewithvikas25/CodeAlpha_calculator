Simple Calculator
Files:
- index.html
- style.css
- script.js

Open index.html in a browser to use the calculator.
